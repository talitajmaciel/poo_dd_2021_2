# poo_dd_2021_2

### Configuração do P5 com Typescript
- Instale o node e o npm no seu computador.
- Faça o clone desse repositório.
```
https://github.com/senapk/poo_dd_2021_2
```
- Copie o arquivo `.gitignore` desse repositório para o seu diretório de trabalho da disciplina.
- Copie a pasta 01_exemplo_ts para o seu diretório de trabalho da disciplina.
- Você pode renomear a pasta para o nome que quiser.
- Entre na pasta copiada e digite o comando `npm install` para instalar os pacotes necessários.
- Dentro da pasta, digite `npm start` para iniciar o servidor.
- Sempre que quiser fazer um novo projeto, basta copiar a pasta, renomear e alterar os arquivos da pasta sketch.